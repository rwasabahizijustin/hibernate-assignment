/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cdg.Library.Dao;

import cdg.Library.Util.HibernateUtil;
import cdg.Libray.Model.Account;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

/**
 *
 * @author Zacharie
 */

public class AccountDao {
    Session session = null;
    public void createAccount(Account ac){
    session = HibernateUtil.getSessionFactory().openSession();
    Transaction trans = session.beginTransaction();
    session.save(ac);
    trans.commit();
    session.close();
    }
     public String FindUsername(String username){
         String password = null;
    session = HibernateUtil.getSessionFactory().openSession();
    Transaction trans = session.beginTransaction();
    List accounts = session.createCriteria(Account.class).add(Restrictions.eq("username",username)).setProjection(Projections.property("password")).list();
    trans.commit();
    session.close();
   for(Object obj:accounts){
   password=obj.toString();
   }
    return password;
    }
     
    
}
